var generateSubmit = (from, text) => {
	return {
		from,
		text

	};
};

module.exports = {generateSubmit};